// Copyright 2005 Google Inc. All Rights Reserved.

#include "s2region.h"

S2Region::~S2Region() {
}

