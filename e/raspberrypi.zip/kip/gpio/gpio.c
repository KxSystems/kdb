#include<stdio.h>
#include<dlfcn.h>
#include<sys/eventfd.h>
#include<time.h>
#include"k.h"
#define K3(f) K f(K x,K y,K z)

V setup(),setup_gpio(I,I,I);I input_gpio(I);
V pwm_set_duty_cycle(I,E),pwm_set_frequency(I,E),pwm_start(I),pwm_stop(I);
I add_edge_detect(I,I,I),add_edge_callback(I,V(*)(I));
// L1:7 L2:8 R1:10 R2:9
// irL:4 irR:17

C _Py_ZeroStruct,_Py_TrueStruct,_Py_NoneStruct,PyExc_RuntimeError,PyExc_ValueError,PyExc_TypeError,PyType_GenericNew,PyArg_ParseTupleAndKeywords,PyGILState_Release,PyInt_AsLong,PyEval_RestoreThread,PyArg_ParseTupleAndKeywords,PyGILState_Release,PyInt_AsLong,PyEval_RestoreThread,PyErr_WarnEx,PyErr_NoMemory,Py_AtExit,PyExc_RuntimeError,PyErr_SetString,PyExc_ValueError,PyExc_TypeError,PyType_GenericNew,PyGILState_Ensure,PyEval_ThreadsInitialized,PyTuple_GetItem,Py_InitModule4,PyErr_Print,PyType_Ready,PyErr_Clear,PyObject_CallFunction,Py_BuildValue,PyErr_Occurred,PyArg_ParseTuple,PyList_Size,PyCallable_Check,PyEval_SaveThread,PyModule_AddObject,PyTuple_Size,PyEval_InitThreads,PyList_GetItem;

Z I d;Z K cbk(I d){K r;J a;read(d,&a,8);R k(0,"gcb",ki(a>>1),kb(a&1),0);}
Z V ii(){Z I f;if(f)R;setup();sd1(d=eventfd(0,0),cbk);f=1;}
Z I ik(K x){R xt==-KB?xg:xt==-KI?xi:xt==-KJ?xj:ni;}Z E ek(K x){R xt==-KE?xe:xt==-KF?xf:xt==-KI?xi:xt==-KJ?xj:nf;}

Z V cbg(I i){J a=(((J)i)<<1)+!!input_gpio(i);write(d,&a,8);}

K2(Kmode){ii();setup_gpio(ik(x),ik(y),0);R 0;}//0output 1input
K2(Ksend){ii();output_gpio(ik(x),ik(y));R 0;}
K1(Kread){ii();R kb(!!input_gpio(ik(x)));}
K1(Kstart){ii();pwm_start(ik(x));R 0;}
K1(Kstop){ii();pwm_stop(ik(x));R 0;}
K2(Kduty){ii();pwm_set_duty_cycle(ik(x),ek(y));R 0;}
K2(Kfreq){ii();pwm_set_frequency (ik(x),ek(y));R 0;}
K3(Kedge){ii();add_edge_detect(ik(x),3,ik(y));add_edge_callback(ik(x),cbg);if(input_gpio(ik(x))!=ik(z))cbg(ik(x));R 0;}//0noedge 1rising 2falling 3both
K1(Kwait){ii();struct timespec t={ik(x)/1000000,ik(x)%1000000};nanosleep(&t,0);R 0;}

