#!/bin/sh
sudo apt-get install -y rlwrap iceweasel
