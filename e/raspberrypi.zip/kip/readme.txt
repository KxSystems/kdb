kip -- kdb+ interface for pi

installation: put the contents of this archive in your home directory.
you might need to install iceweasel(firefox) to run the web camera demo.
see setup.sh

0. gpio/ -- interface to sensors and motors

\l gpio.k

pin mappings:

M is motor control pins (left forward;left backwards;right forward;right backwards)
E is edge ir sensors (edge left;edge right)
L is line ir sensors (line left;line right)
B is the switch button
S is the sonar

gpio functions:

mode[g;i]   sets pin #g mode to output(0) or input(1)
send[g;x]   sets pin #g's output to x (0 or 1)
read[g]     returns the value read from gpio pin #g
edge[g;b;i] enables callback(gcb[g;x]) on pin #g with b ms debounce and assumed initial value i

motor control:

start[g]    enables  pwm control on pin #g
stop[g]     disables pwm control on pin #g
duty[g;f]   sets the duty cycle (percentage of time power is applied) on pin #g to f (0. to 100.)
freq[g;f]   sets the pwm frequency of pin #g to f (default of 1khz should be fine)

misc:

wait[s]     sleep for s us

examples: (cd gpio/ first)

ir.q    -- demo of ir edge sensors. the robot moves forward, avoiding obstacles by turning or backing.
rc.q    -- a simple remote control. run q rc.q -p 5001 and open <pis_ip>:5001 in your phone's browser (has to be in pi's net)
sonar.q -- utility function returning distance in cm measured by sonar sensor

1. cam/ -- camera interface

to run a camera web interface on port 5001, do:
  $ cd ~/cam
  $ ~/q/l32arm/q cam.q
then in your browser (firefox/iceweasel is recommended), go to
  http://your.pi.ip.address:5001
now you can apply your own filters by editing the textarea on the right and clicking 'Send'. 

change PN to 1 in cam.q and [0] to [1] near the end of canvas.html for RGB output

D and \t set camera resolution and fps

* snap[] returns a byte vector from the camera according to the current pixel format (PF)
* cv[n m;x] returns a n x m matrix of corresponding shifts of x; useful for applying an arbitrary convolution kernel, e.g.
   sum sum(1 0 -2;1 1 2;0 1 0)*cv[3 3;10 10#100?10] 
* sb[x] returns sobel filter of a real matrix x
* i48[x] converts 8bit greyscale byte vector x to 4bit greyscale
* c256[x] rescales values of a vector x down to 0x00..0xff


