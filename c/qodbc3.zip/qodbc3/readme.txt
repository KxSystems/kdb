/ qodbc3 changelog. please refer to http://code.kx.com/wiki/Cookbook/ODBC/v3server for documentation

2017.09.11
ps.k
 NEW insert casts nulls
     MIN/MAX for strings and symbols
qodbc3.dll
 NEW show connection dialog when no DSN specified
     allow interactive user/password/host/port prompt in Tableau

2017.01.10
ps.k
 NEW Tableau 10 support
     ps.k uses a single namespace (.s)
     COALESCE and more string functions
 FIX equality casts string scalars
     substring indexes from 1
     timestampadd/diff() for month/quarter/year
     having clause fix
qodbc3.dll
 NEW configure DSN
     l32 build
 FIX bind offset attribute fix for excel/sqlserver

2016.04.25
ps.k
 NEW more string/numeric scalar functions (NB: string scalars correspond to symbols and are trimmed: concat('hi ',' there ') ~ 'hithere'. lists (columns) of strings retain spaces)
     a single space string constant (' ') now maps to q's char atom " "
 FIX mapped nested, enums
     joins now handle duplicates
     insert() with 1 column
     keyed tables

2016.04.06
ps.k
 NEW select with full join support
     like, insert (columns) syntax
     read-only mode support
     compatible with 3.2
 FIX parser for CAST/unary ops/etc
     timestampadd(), timestampdiff(), quarter() etc
qodbc3.dll
 NEW w32 and l64 builds
     DSN name is now a separate field
 FIX username/password field length is now 4096
     stored password now takes priority over the connection string
