/ qodbc3 changelog. please refer to https://code.kx.com/v2/interfaces/q-server-for-odbc3/ for documentation
2024.10.09
qodbc3.dll
 NEW custom authentication using dhup now has a maximum destination buffer size of 65536 bytes (was 4096)
2022.07.19
ps.k
 FIX grouping columns referred to by ordinal position could cause 'by error
 FIX CASE ... WHEN could cause 'type error on empty result sets
qodbc3.dll
 NEW keys in connection strings are now case insensitive
 NEW 64 bit versions can use 1TB ipc limit by setting LRGMSGS=1 in DSN config
 NEW custom authentication using dhup can be statically linked, see customauth.txt for details.

2020.11.25
qodbc3.dll
 FIX password input field in dialog box was not masked
 NEW support for TLS using OpenSSL 1.1

2020.07.09
qodbc3.dll
 FIX pluggable authentication was not used if an empty password was configured in a DSN or dialog box
 NEW new config dialog for windows with test connection option

2019.04.12
qodbc3.dll
 NEW support for pluggable authentication: a library named qodbc3auth.dll (or qodbc3auth.so) can be placed
  in system search path (on windows: system32 directory, PATH system variable, etc), with the following exported function:
   int dhup(char*d,int n,char*h,char*u,char*p) , where
  h is a host:port string; u,p contain the contents of the username, password fields as saved in a DSN or entered into the dialog box.
  d (destination) is the output buffer with length n. non-zero return value signifies error.
  in case qodbc3auth.dll has been found, dhup() is called by the driver to fill the authentication token into d
  the resulting string is passed as khpu's 3rd parameter instead of username:password as specified by the DSN.
  see dhup.c for sample code

2018.07.30
ps.k
 FIX type 77/kdb+3.6 compat
     TRIM could fail for symbols
     < > <= >= for strings and symbols

2018.05.31
ps.k
 FIX kdb+3.6 compatibility
     CASE could fail with 'type
qodbc3.dll
 FIX allow '?' in query string 

2017.09.11
ps.k
 NEW insert casts nulls
     MIN/MAX for strings and symbols
qodbc3.dll
 NEW show connection dialog when no DSN specified
     allow interactive user/password/host/port prompt in Tableau

2017.01.10
ps.k
 NEW Tableau 10 support
     ps.k uses a single namespace (.s)
     COALESCE and more string functions
 FIX equality casts string scalars
     substring indexes from 1
     timestampadd/diff() for month/quarter/year
     having clause fix
qodbc3.dll
 NEW configure DSN
     l32 build
 FIX bind offset attribute fix for excel/sqlserver

2016.04.25
ps.k
 NEW more string/numeric scalar functions (NB: string scalars correspond to symbols and are trimmed: concat('hi ',' there ') ~ 'hithere'. lists (columns) of strings retain spaces)
     a single space string constant (' ') now maps to q's char atom " "
 FIX mapped nested, enums
     joins now handle duplicates
     insert() with 1 column
     keyed tables

2016.04.06
ps.k
 NEW select with full join support
     like, insert (columns) syntax
     read-only mode support
     compatible with 3.2
 FIX parser for CAST/unary ops/etc
     timestampadd(), timestampdiff(), quarter() etc
qodbc3.dll
 NEW w32 and l64 builds
     DSN name is now a separate field
 FIX username/password field length is now 4096
     stored password now takes priority over the connection string
