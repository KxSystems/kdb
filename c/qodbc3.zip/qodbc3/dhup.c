// pluggable authentication sample code
// gcc -shared -o qodbc3auth.so dhup.c
// cl /MD /LD dhup.c /Feqodbc3auth.dll user32.lib 
#include<stdio.h> 
#include<stdlib.h>
#include<string.h>
#if defined(_WIN32)||defined(_WIN64)
#include<windows.h>
#define snprintf _snprintf
#define E __declspec(dllexport)
void out(char*s){MessageBox(0,s,"dhup",0);}
#else
#define E
void out(char*s){printf("%s",s);}
#endif
E int dhup(char*d,int n,char*h,char*u,char*p){char b[4096];snprintf(b,sizeof(b),"dhup(%s,%s,%s)\n",h,u,p);b[sizeof(b)-1]=0;out(b);
 strncpy(d,"newusername:newpassword",n-1);if(n)d[n-1]=0;return 128;}
