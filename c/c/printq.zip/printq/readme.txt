build windows:
cl /LD /MD /DWIN32 pq.c printq.c pq.def q.lib

build linux:
gcc -shared -m32 -o pq.so pq.c printq.c
copy the pq.so in $QHOME/l32 and run $QHOME/l32/q pq.q

PQ can print and K object.

to use it clients, include "printq.h" and copile your code with printq.c.
to print from clients call "pq()" with your object.

r=k(c,0); // listen for updates
pq(r); // print the object
r0(r); // decrement reference count (free)