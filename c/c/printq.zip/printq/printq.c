#include <stdio.h>
#include <string.h>
#include <time.h>
#include "k.h"
#include "printq.h"
#ifdef P
#undef P
#endif
#define P printf
typedef V(*Fa)(K);typedef V(*FA)(K,I);

V pb(C x){P("%d",(I)x);R;};V pg(C x){P("%02x",(I)x);R;}
V ph(H x){P("%d",(I)x);R;};V pi(I x){P("%d",x);R;}
V pj(J x){P("%lld",x);R;};V pe(E x){P("%f",(F)x);R;}
V pf(F x){P("%f",x);R;};V pc(C x){P("%c",x);R;};V ps(S x){P("`%s",x);R;}
V pm(I x){I y,m;m=x+24000;y=m/12;P("%02d%02d.%02d",y/100,y%100,1+m%12);R;}
V pd(I x){struct tm*d;I t=86400*(x+10957);d=localtime(&t);
 P("%04d.%02d.%02d",1900+d->tm_year,1+d->tm_mon,d->tm_mday);R;}
V pv(I x){P("%02d:%02d:%02d",x/3600,x%3600/60,x%60);R;}
V pt(I x){pv(x/1000);P(".%03d",x%1000);R;}
V pz(F x){I d,f;d=(I)x;f=(I)((x-(F)d)*864e5);pd(d);P("T");pt(f);R;}
V pu(I x){P("%02d:%02d",x/60,x%60);R;}

V Pb(K x){pb(xg);R;};V PB(K x,I i){pb(xG[i]);R;}
V Pg(K x){pg(xg);R;};V PG(K x,I i){pg(xG[i]);R;}
V Ph(K x){ph(xh);R;};V PH(K x,I i){ph(xH[i]);R;}
V Pi(K x){pi(xi);R;};V PI(K x,I i){pi(xI[i]);R;}
V Pj(K x){pj(xj);R;};V PJ(K x,I i){pj(xJ[i]);R;}
V Pe(K x){pe(xe);R;};V PE(K x,I i){pe(xE[i]);R;}
V Pf(K x){pf(xf);R;};V PF(K x,I i){pf(xF[i]);R;}
V Pc(K x){pc(xg);R;};V PC(K x,I i){pc(xG[i]);R;}
V Ps(K x){ps(xs);R;};V PS(K x,I i){ps(xS[i]);R;}
V Pm(K x){pm(xi);R;};V PM(K x,I i){pm(xI[i]);R;}
V Pd(K x){pd(xi);R;};V PD(K x,I i){pd(xI[i]);R;}
V Pu(K x){pu(xi);R;};V PU(K x,I i){pu(xI[i]);R;}
V Pz(K x){pz(xf);R;};V PZ(K x,I i){pz(xF[i]);R;}
V Pv(K x){pv(xi);R;};V PV(K x,I i){pv(xI[i]);R;}
V Pt(K x){pt(xi);R;};V PT(K x,I i){pt(xI[i]);R;}

Fa fa[]={Pt,Pv,Pu,0,Pz,Pd,Pm,0,Ps,Pc,Pf,Pe,Pj,Pi,Ph,Pg,0,0,Pb,0};
FA fA[]={0,PB,0,0,PG,PH,PI,PJ,PE,PF,PC,PS,0,PM,PD,PZ,0,PU,PV,PT};
S tt[]={0,"bool",0,0,"byte","short","int","long","real","float","char",
	"symbol",0,"month","date","datetime",0,"minute","seconds","time"};

V pre(K x){I t=xt>0?xt:-xt;if(t==KG)P("0x");else if(t==KC)P("\"");R;}
V pst(K x){I t=xt>0?xt:-xt;if(t==KC)P("\"");else if(t==KB)P("b");
 else if(t==KH)P("h");else if(t==KJ)P("j");else if(t==KM)P("m");R;}

V pa(K x){pre(x);(fa[xt+19])(x);pst(x);R;}
V pA(K x){I i;FA f=fA[xt];if(!xn){P("`%s$()",tt[xt]);R;};if(xn==1)P(",");
 pre(x);for(i=0;i<xn;++i){f(x,i);if((i+1<xn)&&xt!=10&&xt!=11)P(" ");}pst(x);R;}

V pL(K x){I i;P("(");for(i=0;i<xn;++i){pq(xK[i]);if(i+1<xn)P(";");}P(")");R;}

V pxD(K x){if(xK[0]->t==XT)P("(");pq(xK[0]);if(xK[0]->t==XT)P(")");P("!");pq(xK[1]);R;}

V pxT(K x){P("+");pq(xk);R;}

V pq(K x){if(xt==-128)P("error: "),Ps(x);else if(xt<0)pa(x);else if(!xt)pL(x);
 else if(xt==XT)pxT(x);else if(xt==XD)pxD(x);else if(xt<20)pA(x);else P("`n/a: %d",xt);R;}
