#include "k.h"
#include "printq.h"

K1(PQ){pq(x);printf("\n");R ktn(0,0);}
