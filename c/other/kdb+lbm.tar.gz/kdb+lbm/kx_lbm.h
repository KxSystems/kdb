#ifndef _KX_LBM_H
#define _KX_LBM_H

#include <k.h>

/**
 * The maximum length of a wildcard pattern.
 */
#define MAX_PATTERN_SIZE 80

K kx_lbm_connect(K);
K kx_lbm_disconnect(K); 
K kx_lbm_subscribe(K);
K kx_lbm_unsubscribe(K);
K kx_lbm_create_topic(K);
K kx_lbm_send_message(K,K);
K kx_lbm_delete_topic(K);

#endif
