/**
 * The necessary plumbing consists of:
 * - a thread safe bounded queue of messages per topic
 * - a thread safe map of (topic) -> (int, queue, lbm_topic_t*, lbm_rcv_t*).
 */
#ifndef _KX_TOPIC_MAPS
#define _KX_TOPIC_MAPS

#include <pthread.h>
#include <lbm.h>

/**
 * The number of messages we will buffer per queue.
 */
#define BUFFER_SIZE 10000

/**
 * A message is an uninterpreted number of bytes.
 */
typedef struct message_t {
	int size;
	char* data;
}* message;

/**
 * A thread safe bounded queue supporting signaling of full/empty.
 */
typedef struct queue_t {
        message buffer[BUFFER_SIZE];
        int head, tail, full, empty;
        pthread_mutex_t *mutex;
        pthread_cond_t *notFull, *notEmpty;
}* queue;

/**
 * A key is a string.
 */
typedef char* key;
	
/**
 * A value is a file descriptor, a queue of messages, an LBM topic and an LBM receiver.
 */ 	
typedef struct value_t {
	int fd;
	queue message_queue;
	lbm_topic_t *topic;
	lbm_rcv_t *receiver;
	lbm_event_queue_t *event_queue;
}* value;

/**
 * An entry in the hashtable consists of a key, a value, a hash value and a link to another hash entry.
 */
typedef struct entry_t {
	key k;
	value v;
	unsigned int hash;
	struct entry_t *next;
}* entry;

/**
 * A thread safe hashtable.
 */
typedef struct hashtable_t {
	pthread_mutex_t *mutex;
	unsigned int table_length;
	unsigned int entry_count;
	unsigned int load_limit;
	unsigned int prime_index;
	struct entry_t **table;
}* hashtable;

/**
 * Create a queue.
 */
queue kx_create_queue(void);

/**
 * Destroy a queue and its contents.
 */
void kx_destroy_queue(queue);

/**
 * Enqueue a message in the given queue.
 */
void kx_queue_message(queue, message);

/**
 * Dequeue a message from the given queue.
 */
void kx_dequeue_message(queue, message*);

/**
 * Create a queue from the given string.
 */
key kx_create_key(const char*);

/**
 * Delete the given key.
 */
void kx_delete_key(key);

/**
 * Create either a wildcard or topic value with the given parameters. 
 */
value create_value(int, int, lbm_topic_t*, lbm_rcv_t*, lbm_event_queue_t*);

/**
 * Create a value from the given LBM topic and LBM receiver.
 */
value kx_create_value(int, lbm_topic_t*, lbm_rcv_t*, lbm_event_queue_t*);

/**
 * Delete the given value.
 */
void kx_delete_value(value);

/**
 * Create a new hashtable.
 */
hashtable kx_create_hashtable(unsigned long);

/**
 * Insert (key, value) into the given hashtable.
 */ 
void kx_hashtable_insert(hashtable, key, value);

/**
 * Search a hashtable for the given key.
 */
value kx_hashtable_search(hashtable, key);

/**
 * Remove the given key from the hashtable.
 */
value kx_hashtable_remove(hashtable, key);

/**
 * Destroy the given hashtable, destroying all the keys and values as well.
 */
void kx_hashtable_destroy(hashtable);

#endif
