#include <stdio.h>
#include <stdlib.h>
#include <syslog.h>
#include <unistd.h>
#include <errno.h>
#include <lbm.h>
#include <kx_lbm.h>
#include <kx_plumbing.h>

/*
 * This is not thread safe; however, the expected use is that we're initialized once
 * on startup and that is it. 
 */
static int initialized = 0;
static int managed_request_pipe = -1;
static int wildcard_subscriptions_pipe = -1;

/* The prefix for syslog messages. */
static char *SYSLOG_IDENT = "KDB+LBM";
static char *success_string = "OK";

/* This is the byte sent over a pipe to the kdb+ event loop to signal an event has taken place. */
static char nothing = '!';

/* This is a map from file descriptors in the kdb+ event loop to LBM topic and receiver settings. */
static hashtable topics;

/*
 * Most applications, including us, use just a single context. Multiple contexts could be used
 * to provide separate topic namespaces.
 */
static lbm_context_t *lbm_context;
static lbm_context_attr_t lbm_context_attributes;

/*
 * Callback for LBM logging. We redirect the error to syslog.
 */
static log_error(int level, const char *message, void *clientid) {
	syslog(LOG_ERR, "%s", message);
}

/*
 * Callback for handling notification of a new source.
 */
static int handle_source_notification(const char *topic_name, const char *source_name, void *client) {
        K topic = kp((char*)topic_name);
	K source = kp((char*)source_name);
        k(-0, "lbm_new_source", topic, source, (K)0);	
	return 0;
}

/*
 * This function "fakes" matching against the pattern "*". Everything matches!
 */
static int match_anything(const char *topic_str, void *clientd) {
	return 0;
}

/*
 * A sink is an LBM topic and an LBM source object.
 */
typedef struct sink_t {
	    lbm_topic_t *topic;    
	    lbm_src_t *source;      
}* sink;

/*
 * React to an event; we'll read an event from the event queue and turn it into a kdb+ object. 
 * Then, we'll callback to kdb+ to invoke lbm_event, passing the message to process.
 */
static K react_on_event(int pipe) {
	value v;
	(void) read(pipe, &v, sizeof(queue));
	message m;
	kx_dequeue_message(v->message_queue, &m);
	K list = ktn(KG, m->size);
	(void) memcpy(kG(list), m->data, m->size);
	k(-0, "lbm_event", ki(pipe), list, (K)0);
	free(m->data);
	free(m);
	return 0;
}

/*
 * React to a message; we'll read the request and and call back to kdb+
 * to invoke a callback to process (and possibly respond to) the incoming message. 
 */
static K react(int pipe, char *callback) {
        lbm_msg_t *message = 0;
        (void) read(pipe, &message, sizeof(lbm_msg_t*));
	K topic = kp(message->topic_name);
	K handle = kj((long)message);
        K list = knk(2, topic, handle);
        k(-0, callback, list, (K)0);
	if (0 != message)
       	 	lbm_msg_delete(message);
        return 0;
}

/**
 * React to a wildcard event.
 */
static K react_on_wildcard_event(int pipe) {
        return react(pipe, "lbm_wildcard_event");
}

/**
 * React to a request message.
 */
static K react_to_request(int pipe) {
        return react(pipe, "lbm_event");
}

/**
 * Return the LBM version.
 */
K kx_lbm_version(K x) {
	K version = kp((char*)lbm_version());
	return version;
}

/**
 * Use the given LBM config.
 */
K kx_use_lbm_config(K x) {
	char *result = success_string;
	char *config = calloc(x->n+1, 1);
        strncpy(config, kC(x), x->n);

	if (LBM_FAILURE == lbm_config(config)) {
		result = (char*) lbm_errmsg();
	}
	free(config);
	return kp(result);
}

/**
 * Log an informational message via syslog.
 */
K kx_syslog(K x) {
        /* Check the type of the message and take a copy. */
        if (10 != x->t)
                return krr("Wrong type; the message must be string.");

	/* Log the message and clean up our temporary copy. */
        char *message = calloc(x->n+1, 1);
        strncpy(message, kC(x), x->n);
        syslog(LOG_INFO, "%s", message);
        free(message);

        return kp(success_string);
}

/**
 * Set up our connection to LBM and a pipe back to kdb+ when events occur.
 */
K kx_lbm_connect(K x) {
	static lbm_src_notify_func_t source_notify;
	
	/* On first call we initialize. */
	if (0 == initialized) {
		if (-KI != x->t)
			return krr("Usage: connect[port] where port is an integer");
		khp("", xi);
		
		/* Initialize syslog connection. */
		openlog(SYSLOG_IDENT, LOG_CONS|LOG_NDELAY|LOG_PID, LOG_USER);

		/* Create a map from event pipe descriptor to LBM topics. */
		topics = kx_create_hashtable(10001);

		/* Initialize LBM logging to syslog and the event queue. */
		if (LBM_FAILURE == lbm_log(log_error, NULL) || LBM_FAILURE == lbm_context_attr_init(&lbm_context_attributes)) 
			goto error;
			
		/* Set up the source notification callback in the context attributes. */	
		source_notify.clientd = NULL;
		source_notify.notifyfunc = handle_source_notification;
		if (LBM_FAILURE == 
		    lbm_context_attr_setopt(&lbm_context_attributes, "resolver_source_notification_function", &source_notify, sizeof(source_notify)))
			goto error;
			
		/* Initialize the LBM context. */	
		if (LBM_FAILURE == lbm_context_create(&lbm_context, &lbm_context_attributes, NULL, NULL))
			goto error;
		
		initialized = 1;
	}
	else {
		/* Do nothing because we have already initialized. */	
	}
	
success:	
	return kp(success_string);
error:
	kx_hashtable_destroy(topics);
	return kp((char*)lbm_errmsg());
}

/**
 * Disconnect the LBM system.
 */
K kx_lbm_disconnect(K x) {
	/* Free the event pipes, closing each one. */
	if (0 != topics) {
		kx_hashtable_destroy(topics);
		topics = 0;
	}

	/* Delete the LBM context. */
	lbm_context_delete(lbm_context);
	initialized = 0;
	
	return kp(success_string);	
}

/*
 * A callback for us in the "managed" functions. That is, where the topics etc. are maintained
 * on the C side of the kdb+ integration.
 */
static int receiver_callback(lbm_rcv_t *receiver, lbm_msg_t *lbm_message, void *clientd) {
	static messages_received = 0;
	static null_messages = 0;
	value v;
	switch (lbm_message->type) {
	case LBM_MSG_DATA:
		if (0 == lbm_message->len)
			null_messages++;
		else
			messages_received++;
		/* Try to find an exact match. */
		v = kx_hashtable_search(topics, (key)(lbm_message->topic_name));
		if (0 != v) {
			message m = malloc(sizeof(message));	
        		m->data = calloc(lbm_message->len, 1);
			m->size = lbm_message->len;
        		(void) memcpy(m->data, lbm_message->data, lbm_message->len);
			kx_queue_message(v->message_queue, m);
        		write(v->fd, &(v), sizeof(value));
		}
		/* Otherwise, see if we should put it in the wildcard bucket. */
		else if (-1 != wildcard_subscriptions_pipe) {
			lbm_msg_retain(lbm_message);
 			write(wildcard_subscriptions_pipe, &lbm_message, sizeof(lbm_msg_t*));
		}
		break;
	case LBM_MSG_EOS:
		syslog(LOG_ERR, "%s Null:%d Data:%d", "LBM_MSG_EOS", null_messages, messages_received);
		null_messages = messages_received = 0;
		break;
	case LBM_MSG_UNRECOVERABLE_LOSS:
		syslog(LOG_ERR, "%s", "LBM_MSG_UNRECOVERABLE_LOSS");
		break;
	case LBM_MSG_UNRECOVERABLE_LOSS_BURST:
		syslog(LOG_ERR, "%s", "LBM_MSG_UNRECOVERABLE_LOSS_BURST");
		break;
	case LBM_MSG_REQUEST:
                if (0 == lbm_message->len)
                        null_messages++;
                else
                        messages_received++;
		lbm_msg_retain(lbm_message);
		if (-1 == managed_request_pipe)
			syslog(LOG_ERR, "%s", "LBM_MSG_REQUEST received but we're not enabled for requests/responses.");
		else
			write(managed_request_pipe, &lbm_message, sizeof(lbm_msg_t*));	
		break;
	default:
		syslog(LOG_ERR, "Unknown lbm_msg_t type %x [%s][%s]\n", lbm_message->type, lbm_message->topic_name, lbm_message->source);
		break;
	}
	return 0;
}

/*
 * Add a topic that we wish to subscribe to.
 */
static K subscribe(K x, int wildcard, lbm_event_queue_t *event_queue) {
	if (!initialized)
		return krr("You can only subscribe after you connect to LBM");
		
	/* Check the type of the topic and take a copy. */
	if (10 != x->t)
		return krr("Wrong type; must be string");
	char *topic = calloc(x->n+1, 1);
	strncpy(topic, kC(x), x->n);

	/* Create the (key, value) and insert if its a new topic. */
	key k = (key)topic;
	if (kx_hashtable_search(topics, k)) {
		/* We're already subscribed to this topic. */
		kx_delete_key(k);
		return krr("Duplicate topic.");
	}
	
	if (0 == wildcard) {
                /* Set up a pipe to signal the kdb+ main loop that an event for this topic is queued. */
                int event_pipe[2];
                pipe(event_pipe);
		lbm_topic_t *lbm_topic;
		lbm_rcv_t *lbm_receiver;
		lbm_rcv_topic_lookup(&lbm_topic, lbm_context, topic, NULL);   
		lbm_rcv_create(&lbm_receiver, lbm_context, lbm_topic, receiver_callback, NULL, event_queue); 	
		value v = kx_create_value(event_pipe[1], lbm_topic, lbm_receiver, event_queue); 
		kx_hashtable_insert(topics, k, v);
		sd1(event_pipe[0], react_on_event);
		return ki(event_pipe[0]);
	}
	else if (1 == wildcard) {
		/* Retrieve the current wildcard receiver attributes */
		lbm_wildcard_rcv_t *wildcard_receiver;
		lbm_wildcard_rcv_attr_t wildcard_receiver_attributes;
		if (LBM_FAILURE == lbm_wildcard_rcv_attr_init(&wildcard_receiver_attributes))
			goto error;

		/*
	 	 * If the pattern type is PCRE or regex, then check the pattern. "*" is not a regular expression, so
		 * we make a special application handler for it that acts as you would expect it to.
		 *
		 * NOTE: This only applies to just "*". Something like ".*" is not changed, etc.
		 */
		int pattern_type = 0;
		size_t unused = sizeof(int);
		if (LBM_FAILURE == lbm_wildcard_rcv_attr_getopt(&wildcard_receiver_attributes,
			"pattern_type", &pattern_type, &unused))
			goto error;

		if ((LBM_WILDCARD_RCV_PATTERN_TYPE_PCRE == pattern_type|| LBM_WILDCARD_RCV_PATTERN_TYPE_REGEX == pattern_type) 
		    && 0 == strcmp(topic, "*")) {

			/* Create the wildcard receiver using a callback. */
			lbm_wildcard_rcv_compare_func_t comparison_function;
			pattern_type = LBM_WILDCARD_RCV_PATTERN_TYPE_APP_CB;

			if (LBM_FAILURE == lbm_wildcard_rcv_attr_setopt(&wildcard_receiver_attributes, "pattern_type", &pattern_type, sizeof(pattern_type))) 
				goto error;
			comparison_function.compfunc = match_anything;
			comparison_function.clientd = NULL;

			if (LBM_FAILURE == lbm_wildcard_rcv_attr_setopt(&wildcard_receiver_attributes, "pattern_callback", &comparison_function, sizeof(comparison_function))) 
				goto error;
		} 
		else {
			/* Create the wildcard receiver normally. */
			char pattern_type_string[MAX_PATTERN_SIZE];
			size_t pattern_type_length = sizeof(pattern_type_string);
			if (LBM_FAILURE == lbm_wildcard_rcv_attr_str_getopt(&wildcard_receiver_attributes, "pattern_type", pattern_type_string, &pattern_type_length))
				goto error;
		}

		/* Create the wildcard receiver using the default (or configured) pattern type. */
		if (LBM_FAILURE == lbm_wildcard_rcv_create(&wildcard_receiver, lbm_context, topic, NULL, 
							   &wildcard_receiver_attributes, receiver_callback, NULL, event_queue))	
			goto error;
		
		return kj((long)(wildcard_receiver));	
	}
	
error:
	free(topic);
	return krr((char*)lbm_errmsg());	
}


/**
 * Add a topic that we wish to subscribe to.
 */
K kx_lbm_subscribe(K x) {
	return subscribe(x, 0, NULL);
}

/**
 * Add a wildcard that we wish to subscribe to.
 */
K kx_lbm_wildcard_subscribe(K x) {
        /* Set up a pipe to signal the kdb+ main loop that a request is queued. */
        if (wildcard_subscriptions_pipe = -1) {
		int event_pipe[2];
        	if (0 > pipe(event_pipe)) 
                	return kp(strerror(errno));
        	wildcard_subscriptions_pipe = event_pipe[1];
        	sd1(event_pipe[0], react_on_wildcard_event);
	}
	return subscribe(x, 1, NULL);
}

/*
 * A null event queue monitor; we ignore the statistics.
 */
static int event_queue_monitor(lbm_event_queue_t *queue, int event, size_t queue_size, lbm_ulong_t event_delay_usec, void *clientd) {
	return 0;
}

/**
 * Create an event queue.
 */
K kx_new_event_queue(K x) {
	lbm_event_queue_t *event_queue = NULL;

	/* Create an event queue (with monitor callback) */
	if (LBM_FAILURE == lbm_event_queue_create(&event_queue, event_queue_monitor, NULL, NULL))
		return krr((char*)lbm_errmsg());
	else
		return kj((long)event_queue);
}

/**
 * Add a topic that we wish to subscribe to using an event queue.
 */
K kx_lbm_subscribe_topic_with_event_queue(K x, K y) {
	return subscribe(y, 0, (lbm_event_queue_t*) x->j);
}

/**
 * Add a wildcard that we wish to subscribe to using an event queue.
 */
K kx_lbm_subscribe_wildcard_with_event_queue(K x, K y) {
	return subscribe(y, 1, (lbm_event_queue_t*) x->j);
}

/**
 * Process a message from the event queue.
 */
K kx_lbm_process_event_queue(K x) {
	/* Check the type of the argument. */
	if ( -7 != x->t)
                return krr("Wrong type; second argument must be a long");
	
	/* Get the event queue, dispatch to it, and then return whatever caused us to stop dispatching. */
	lbm_event_queue_t *event_queue = (lbm_event_queue_t*)(x->j);
	int messages_processed = lbm_event_dispatch(event_queue, LBM_EVENT_QUEUE_POLL);
	if (LBM_FAILURE == messages_processed)
		return krr((char*)lbm_errmsg());
	else 
		return ki(messages_processed);
}

/**
 * Unsubscribe from the topic.
 */
K kx_lbm_unsubscribe(K x) {
	if (!initialized)
		return krr("Can only unsubscribe when connected");
		
        /* Check the type of the topic and take a copy. */
        if (10 != x->t)
                return krr("Wrong type; must be string.");
	
	/* Take a copy of the topic we are trying to unsubscribe from. */
	char *topic = calloc(x->n+1, 1);
	strncpy(topic, kC(x), x->n);
	
	value v = kx_hashtable_remove(topics, topic);
	kx_delete_value(v);
	
	free(topic);
	return kp(success_string);
}

/**
 * Unsubscribe from a wildcard.
 */
K kx_lbm_wildcard_unsubscribe(K x) {
        if (!initialized)
                return krr("Can only unsubscribe when connected");

        /* Check the type of the topic and take a copy. */
        if (-7 != x->t)
                return krr("Wrong type; must be long.");

	lbm_wildcard_rcv_t *receiver = (lbm_wildcard_rcv_t*)(x->j);
	if (LBM_FAILURE == lbm_wildcard_rcv_delete(receiver))
		return krr((char*)lbm_errmsg());
	else
        	return kp(success_string);
}

/**
 * Create an LBM topic in the current context.
 */
K kx_lbm_create_topic(K x) {
	/* Check that LBM has been initialized. */
        if (!initialized)
                return krr("Can only subscribe when connected");

        /* Check the type of the topic and take a copy. */
        if (10 != x->t)
                return krr("Wrong type; must be string");
        char *topic = calloc(x->n+1, 1);
        strncpy(topic, kC(x), x->n);

	/* Create the LBM topic and return it. */
	sink s = malloc(sizeof(struct sink_t));
    	if (LBM_FAILURE == lbm_src_topic_alloc(&(s->topic), lbm_context, topic, NULL)
	    || LBM_FAILURE == lbm_src_create(&(s->source), lbm_context, s->topic, NULL, NULL, NULL)) {
		free(topic); 
		free(s); 
    		return krr((char*) lbm_errmsg());
	}
	return kj((long long)s);
}

/**
 * Send a message x on the topic y. This assumes x is a string or a byte vector
 * and y a long (from a previous topic subscription).
 */
K kx_lbm_send_message(K x, K y) {
        /* Check the type of the message. */
        if (10 != x->t && 4 != x->t){
                return krr("Wrong type; first argument must be string or byte vector");
	}
	if ( -7 != y->t)
                return krr("Wrong type; second argument must be a long");

	/* Turn y into an lbm sink. */
	sink s = (sink)(y->j);
	
	/* Send the message. */	
	int error = lbm_src_send(s->source, kG(x), x->n, LBM_MSG_FLUSH | LBM_SRC_BLOCK);
	if (-1 == error)
		return krr((char*) lbm_errmsg());
	else	
		return kp(success_string);
}

/**
 * Enables request/response processing for topics we're receiving messages for.
 */
K kx_lbm_enable_requests(K x) {
	/* Check that LBM has been initialized. */
        if (!initialized)
                return krr("You can only enable request/response processing after you connect to LBM");

        /* Set up a pipe to signal the kdb+ main loop that a request is queued. */
        int event_pipe[2];
        if (0 > pipe(event_pipe)) {
                return kp(strerror(errno));
        }
	managed_request_pipe = event_pipe[1];

	/* We assume that the topic is in place and we'll just queue up notices of requests. */
        sd1(event_pipe[0], react_to_request);
        return ki(event_pipe[0]);
}

/**
 * Send a message x in response to message object y. This assumes x is a string or byte
 * vector and y a long that is in fact a pointer to an existing response object.
 */
K kx_lbm_respond(K x, K y) {
        /* Check the type of the message. */
        if (10 != x->t && 4 != x->t)
                return krr("Wrong type; first argument must be string or byte vector.");
        if ( -7 != y->t)
		return krr("Wrong type; second argument must be a pointer to a message object.");
	
	/* Turn y into an lbm request. */	
        lbm_msg_t *request = (lbm_msg_t*)(y->j);
        
	/* Send the response. */
        int error = lbm_send_response(request->response, kG(x), x->n, LBM_SRC_BLOCK);
        if (-1 == error)
                return krr((char*) lbm_errmsg());
        else
                return kp(success_string);
}

/**
 * Delete a context from the current topic.
 */
K kx_lbm_delete_topic(K x) {
	/* Check that LBM has been initialized. */
        if (!initialized)
                return krr("Can only delete a topic when connected");

        /* Check the type of the topic and take a copy. */
        if (-7 != x->t)
                return krr("Wrong type; must be a topic");

	/* Delete the source source associated with the topic. */
	sink s = (sink)(x->j);
	lbm_src_delete(s->source);
	return kp(success_string);
}
