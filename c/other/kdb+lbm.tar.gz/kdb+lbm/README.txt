This code is a basic integration with the 29west LBM messaging system for 
posix systems; we assume pthreads and syslog.

Adjust the Makefile for your kdb+ and LBM installation. Then, use make to 
compile and install the C code. The example .q scripts can be used to test 
the integration. 

See the .q scripts for examples on how to use this integration. The main thing to
change is the encoding/decoding of messages which depends on what you want to
send and how the subscribers expect it to be packed.

Example usage:

# start a receiver
q ./recvtest.q

# start a sender
q ./sendtest.q

And then check in the receiver that the messages arrived:
q)count messages
10000
q)messages
id message
----------
11 "Hello"
11 "Hello"
11 "Hello"
11 "Hello"
..

speedtest.q can be used to check send speeds. lbmrcv FOO will receive the
messages and display some metrics. 

To check the receiver/response integration we can lbmreq FOO to generate
some requests to a running "q ./recvtest.q" and see that we respond as expected.

lbmrcv and lbmreq are 29west test programs packaged with the LBM product.

Using verbose output from lbmreq:

lbmreq FOO -v -v

will allow us to see the response text that we sent. For example:

testmachine> lbmreq FOO -v -v
Using TCP port 4392 for responses
Delaying requests for 1000 milliseconds
Receiver connect [TCP:10.43.23.198:58384]
Sending request 0
Pausing 5 seconds.
Sent request 0.  Response [TCP:10.43.23.198:37672][0], 5 bytes
48 65 6c 6c 6f                                          Hello           
Done waiting for responses. 1 responses (5 bytes) received. Deleting request.
Quitting...

Where "Hello" was the response from the q server to the request.

event_queue_test.q tests using LBM event queues to buffer incoming messages.

wildcard_test.q tests matching against wildcard topics.

Notes:

1. The C code expects to be able to call back to various kdb+ functions:

	- "lbm_event" when an incoming message arrives to a subscribed topic. The lbm_event 
	function will receive the handle of the open subscription as well as the actual message. 
	It should decide based on the handle what to do with the message. The example
	simple appends all incoming messages to a single table - that would change in practice.

	For example, assuming we wish messages to be inserted into a table:
	
	messages:([]id:(); message:())

	Then we would define lbm_event as follows:
	
	lbm_event:{[subscriber;message] 
		messages ,: (subscriber; message)
	 }
	
	- "lbm_request" when an incoming request message arrives. The lbm_request function
	will receive the a list of message components. The first item is the topic and the
	second item is a handle to the underlying LBM message object. 
	
	For example, to respond to any incoming request with "Hello", lbm_request can be 
	defined as follows:
	
	lbm_request:{[lbm_message]
		topic:lbm_message[0];
		handle:lbm_message[1];
		sendresponse["Hello";handle]	
	 }
	
	- "lbm_new_source" when we are in wildcard receive mode and a new data source is detected.
	
	- "lbm_wildcard_event" when an incoming message arrives to a subscribed topic. The lbm_wildcard_event 
	function will receive the handle of the open subscription as well as the actual message. 
	It should decide based on the handle what to do with the message. The example
	simple appends all incoming messages to a single table - that would change in practice.

	For example, assuming we wish messages to be inserted into a table:
	
	messages:([]id:(); message:())

	Then we would define lbm_wildcard_event as follows:
	
	lbm_wildcard_event:{[lbm_message] 
       		topic:lbm_message[0];
       		handle:lbm_message[1];
        	messages ,: (handle; topic)
	 }	

2. We assume outgoing messages are serialized as strings or byte vectors before calling any functions.

3. We assume incoming messages can be treated as byte vectors. Cast to string to
get a readable version assuming you sent a string. For example:

If we sent "Hello" then we'd receive 0x48656c6c6f as the message. Casting back
to string, we rebuild the original message.

q)`char$0x48656c6c6f
"Hello" 

