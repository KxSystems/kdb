#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <kx_plumbing.h>

/** 
 * Lock the given mutex.
 */
#define LOCK(X) pthread_mutex_lock((X)->mutex)

/** 
 * Unlock the given mutes.
 */
#define UNLOCK(X) pthread_mutex_unlock((X)->mutex)

/**
 * A null topic identifier.
 */
static const char *null_topic = "NULL TOPIC";

/** 
 * Create a queue.
 */
queue kx_create_queue(void) {
	/* Allocate the queue. */
        queue q = malloc(sizeof (struct queue_t));
        q->empty = 1; q->full = q->head = q->tail = 0;

	/* Allocate the mutex for the queue. */
        q->mutex = malloc(sizeof(pthread_mutex_t));
        pthread_mutex_init(q->mutex, NULL);

	/* Allocate the condition variables. */
        q->notFull = malloc(sizeof(pthread_cond_t));
        pthread_cond_init (q->notFull, NULL);
	q->notEmpty = malloc(sizeof(pthread_cond_t));
	pthread_cond_init(q->notEmpty, NULL);
	
        return q;
}

/**
 * Destroy the given queue. Note that although we lock the queue,
 * we never unlock it. This is expected; the queue doesn't exist 
 * to unlock and the queue pointer itself will be trashed.
 */
void kx_destroy_queue(queue q) {
        LOCK(q);

	/* Destroy the queue contents. */
	message message;
        while (q->head != q->tail) {
                message  = q->buffer[q->head];
                free(message);
                q->head++;
                if (BUFFER_SIZE == q->head)
                        q->head = 0;
        }

	/* Destroy and free the mutex and condition variables. */
        pthread_mutex_destroy(q->mutex);
	pthread_cond_destroy(q->notFull);
	pthread_cond_destroy(q->notEmpty);
        free(q->mutex);
        free(q->notFull);

	/* Free the queue itself. */
        free(q);
}

/**
 * Enqueue the given message into the queue. This function will block if
 * the queue is full.
 */
void kx_queue_message(queue q, message m) {
        LOCK(q);

	/* If the queue is full, block until there is space. */
	while (q->full) {
                pthread_cond_wait(q->notFull, q->mutex);
	}
	
	/* Enqueue the message. */
        q->buffer[q->tail] = m;
        q->tail++;
        if (BUFFER_SIZE == q->tail)
                q->tail = 0;
        if (q->tail == q->head)
                q->full = 1;
        q->empty = 0;
        UNLOCK(q);

	/* If the queue was empty before we added the message, signal any waiting threads 
	   that there is now a message to be processed. */
	pthread_cond_signal(q->notEmpty);
}

/*
 * Dequeue a message from the given q.
 */
void kx_dequeue_message(queue q, message *out){
        LOCK(q);

	/* If the queue is empty, block until there is a message. */
	while (q->empty) {
		pthread_cond_wait (q->notEmpty, q->mutex);
	}
	if (q->empty) {
		return;
	}
	
	/* Dequeue the message. */
        *out = q->buffer[q->head];
        q->head++;
        if (BUFFER_SIZE == q->head)
                q->head = 0;
        if (q->head == q->tail)
                q->empty = 1;
        q->full = 0;
        UNLOCK(q);

	/* If the queue was full before we removed the message, signal any waiting threads 
	   that there is now space to add more messages. */
        pthread_cond_signal(q->notFull);
}


/**
 * Create a key object; copies parameters rather than taking ownership. 
 */
key kx_create_key(const char *topic) {
	size_t length = strlen(topic);
	key k = calloc(length + 1, 1);
	
	/* Copy the topic, or if its null, a null topic string. */
	if (0 == topic)
		topic = null_topic;
	strcpy(k, topic);

	return k;
}

/**
 * Delete a key object.
 */
void kx_delete_key(key k) {
	if (0 == k)
		return;
	free(k);
}


/**
 * Create a value; does not copy the parameters instead takes a reference and ownership.
 */
value kx_create_value(int fd, lbm_topic_t *topic, lbm_rcv_t *receiver, lbm_event_queue_t *event_queue) {
	value v = malloc(sizeof(struct value_t));
	v->fd = fd;
	v->message_queue = kx_create_queue();
	v->topic = topic;
	v->receiver = receiver;
	v->event_queue = event_queue;
	return v;
}

/**
 * Delete a value and its contents. Deletes the receiver but not the topic as
 * LBM itself takes care of that. 
 */ 
void kx_delete_value(value v) {
	if (0 == v)
		return;

	/* Remove the file descriptor from the kdb+ event loop and close it. */
	sd0(v->fd);
		
	/* Delete any associated topic receiver. */
	if (0 != v->receiver) 
		lbm_rcv_delete(v->receiver);

	/* Delete the associated event queue. */
	if (0 != v->event_queue) {
		lbm_event_queue_delete(v->event_queue);
	}
	
	/* Destroy the queue and free the value. */
	kx_destroy_queue(v->message_queue);
	free(v);
}

/*
 * Calculate the index of a hash value for the given table length. 
 */
static inline unsigned int index_for(unsigned int table_length, unsigned int hash_value) {
    return (hash_value % table_length);
}

/*
 * Primes used in the hashtable.
 */
static const unsigned int primes[] = {53, 97, 193, 389, 769, 1543, 3079, 6151, 12289, 24593, 49157, 98317, 196613, 393241, 
	786433, 1572869, 3145739, 6291469, 12582917, 25165843, 50331653, 100663319, 201326611, 402653189, 805306457, 1610612741
};

/*
 * A prime table length.
 */
static const unsigned int prime_table_length = sizeof(primes)/sizeof(primes[0]);

/*
 * The default load factor on the hash table.
 */
static const float max_load_factor = 0.65;

/*
 * Two keys are equal if the topics are equal strings. 
 */
static inline int equals(key left, key right) {
        return !strcmp(left, right);
}

/*
 * A reasonable hash function. (Can be improved if significant load on the table is expected).
 */
static unsigned long hash_function (key k) {
	unsigned long hash = 0;
	int c;
	if (0 == k)
		return 0;
	while (c = *k++)
		hash = c + (hash << 6) + (hash << 16) - hash;

	return hash;
}

/* 
 * Double the size of the table to accomodate more entries.
 */
static void hashtable_expand(hashtable h) {
	struct entry_t **new_table;
	struct entry_t *entry;
	unsigned int new_size, i, index;

	/* Check we're not hitting max capacity */
	if ((prime_table_length - 1) == h->prime_index) 
		return;
	
	/* Allocate the new table. */	
	new_size = primes[++(h->prime_index)];
	new_table = malloc(sizeof(struct entry_t*) * new_size);
	memset(new_table, 0, new_size * sizeof(struct entry_t *));
    
	/* This algorithm is not 'stable'. ie. it reverses the list when it transfers entries between the tables */
	for (i = 0; i < h->table_length; i++) {
		while (0 != (entry = h->table[i])) {
			h->table[i] = entry->next;
			index = index_for(new_size, entry->hash);
			entry->next = new_table[index];
			new_table[index] = entry;
		}
	}
	
	/* Free the old table and update the table details for the new size. */
	free(h->table);
	h->table = new_table;
	h->table_length = new_size;
	h->load_limit = (unsigned int) ceil(new_size * max_load_factor);
}

/**
 * Create a hashtable with the specified minimum size.
 */
hashtable kx_create_hashtable(unsigned long min_size) {
	hashtable h;
	unsigned int prime_index, size = primes[0];
    
	/* Check requested hashtable isn't too large. */
	if (min_size > (1u << 30)) 
		return 0;
    
	/* Enforce size as prime. */
	for (prime_index = 0; prime_index < prime_table_length; prime_index++) {
		if (primes[prime_index] > min_size) { 
			size = primes[prime_index]; 
			break; 
		}
	}
    
	/* Initialize the hashtable. */
	h = malloc(sizeof(struct hashtable_t));
	h->table = malloc(sizeof(struct entry*) * size);
	memset(h->table, 0, size * sizeof(struct entry *));
	h->mutex = malloc(sizeof(pthread_mutex_t));
	pthread_mutex_init(h->mutex, NULL);
	h->table_length = size;
	h->prime_index = prime_index;
	h->entry_count = 0;
	h->load_limit = (unsigned int) ceil(size * max_load_factor);
	return h;
}

/**
 * Insert (key, value) in the hashtable, allowing duplicates.
 */
void kx_hashtable_insert(hashtable h, key k, value v) {
	LOCK(h);
	unsigned int index;
	struct entry_t *entry;
	
	/* If the new entry would push past our load limit, try to expand the table. */
	if (++(h->entry_count) > h->load_limit)
		hashtable_expand(h);

	/* Insert the new entry. */
	entry = malloc(sizeof(struct entry_t));
	entry->hash = hash_function(k);
	index = index_for(h->table_length, entry->hash);
	entry->k = k;
	entry->v = v;
	entry->next = h->table[index];
	h->table[index] = entry;
	UNLOCK(h);
}

/**
 * Search in h for k, returning the value if found.
 */
value kx_hashtable_search(hashtable h, key k) {
	LOCK(h);
	struct entry_t *entry;
	
	/* Find the bucket that would contain the key. */
	unsigned int index, hash_value = hash_function(k);
	index = index_for(h->table_length, hash_value);
	entry = h->table[index];
	
	/* Search the bucket. */
	while (0 != entry) {
		if ((hash_value == entry->hash) && (equals(k, entry->k))) {
			UNLOCK(h);
			return entry->v;
		}	
	entry = entry->next;
	}
	UNLOCK(h);
	return 0;
}

/**
 * Remove a k from h. Note we don't compact the table when the load factor drops.
 */
value kx_hashtable_remove(hashtable h, key k) {
	struct entry_t *entry, **next;
	value v;
	unsigned int index, hash_value = hash_function(k);
	if (0 == h)
		return;
	LOCK(h);
	
	/* Find the bucket that would contain the key. */
	index = index_for(h->table_length, hash_function(k));
	next = &(h->table[index]);
	entry = *next;
	
	/* Search the bucket, removing the entry if it matches. */
	while (0 != entry) {
		if ((hash_value == entry->hash) && (equals(k, entry->k))) {
			*next = entry->next;
			h->entry_count--;
			v = entry->v;
			kx_delete_key(entry->k);
			free(entry);
			UNLOCK(h);
			return v;
        	}
        	next = &(entry->next);
        	entry = entry->next;
	}
	UNLOCK(h);
	return 0;
}

/**
 * Destroy a hashtable, deleting all the keys and values.
 * Note that although we lock the table, we never unlock it. 
 * This is expected; the table doesn't exist to unlock and the 
 * table pointer itself will be trashed.
 */
void kx_hashtable_destroy(hashtable h) {
	unsigned int i;
	struct entry_t *next, *current;
	struct entry_t **table = h->table;
	LOCK(h);
	
	/* Delete all the entries in the table. */
	for (i = 0; i < h->table_length; i++) {
		next = table[i];
		while (0 != next) { 
			current = next; 
			next = next->next; 
			kx_delete_key(current->k); 
			kx_delete_value(current->v); 
			free(current); 
		}
        }

	/* Free the table itself. */ 
	free(h->table);
	pthread_mutex_destroy(h->mutex);
	free(h);
}

